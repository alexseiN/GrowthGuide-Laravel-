<?php

declare(strict_types=1);

namespace Faker\Extension;

/**
 * An extension is the only way to add new functionality to Faker.
 *
 * @experimental This interface is experimental and does not fall under our BC promise
 */
interface Extension
{
}
